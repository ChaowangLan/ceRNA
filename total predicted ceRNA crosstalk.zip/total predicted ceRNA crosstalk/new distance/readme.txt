For a line in each files:

The ceRNA crosstalk is show below:

['ENSG00000226482', 'hsa-miR-4430', 'CIDEA']	0.00142758779825
        |                |              |               |
        |                |              |               |
        |                |              |               |
      lncRNA            miRNA        gene(mRNA)       competition score

The higher the competition score, the more reliable the ceRNA crosstalk.
