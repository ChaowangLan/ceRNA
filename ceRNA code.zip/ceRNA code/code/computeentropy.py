import math
import operator

class readfile(object):
    def __init__(self,a):
        self.readpath = a

    def handlefile(self,writepath,readpath):
        file_objectR = open(readpath)
        file_objectW = open(writepath)
        try:
            line = file_objectR.read()
        finally:
            file_objectR.close()
            file_objectW.close()

    def complexhandlefile(self):
        ##change the route

        miRNAbinaexpfile = "newdata/binarymiRNA.txt"
        lncRNAbinaexpfile = "newdata/binarylncRNA.txt"
        mRNAbinaexpfile = "newdata/binarygene.txt"

        miRNAnamefile = "newdata/ERhavemiRNA.txt"
        lncRNAnamefile = "newdata/ERhavelncRNA.txt"
        mRNAnamefile = "newdata/ERhavegene.txt"

        miRmRtargetfile = "predicttarget/targetmRNAmiRNA.txt"
        miRlncRtargetfile = "predicttarget/targetlncRNAmiRNA.txt"

        ceRNAfile = "ERdata/MMIceRNA.txt"
        doublelist = {}
        singlelist = {}
        triplist = {}
        miRNAnamelist = []
        miRNAexplist = []

        mRNAnamelist = []
        mRNAexplist =[]

        lncRNAnamelist = []
        lncRNAexplist = []

        miRNAlncRNAtardict = {}
        miRNAmRNAtardict = {}

        miRNAlncRNAtarnumlist =[]
        miRNAmRNAtarnumlist = []

        uselncRNAexpdict = {}
        usemRNAexpdict = {}
        usemiRNAexpdict = {}

        suppdict = {}
        lnRsuppdict = {}
        entropydict = {}

        totalnum = 0

        miRNAnamelist = self.readnamefile(miRNAnamefile)
        mRNAnamelist = self.readnamefile(mRNAnamefile)
        lncRNAnamelist = self.readnamefile(lncRNAnamefile)
        
        miRNAexplist = self.readbinaexpfile(miRNAbinaexpfile)
        mRNAexplist = self.readbinaexpfile(mRNAbinaexpfile)
        lncRNAexplist = self.readbinaexpfile(lncRNAbinaexpfile)
        miRNAlncRNAtardict = self.readTarfile(miRlncRtargetfile)
        miRNAmRNAtardict = self.readTarfile(miRmRtargetfile)
        
        uselncRNAexpdict = \
          self.getTarRNAexplist(miRNAlncRNAtardict,lncRNAnamelist,lncRNAexplist)
        usemRNAexpdict = \
          self.getTarRNAexplist(miRNAmRNAtardict,mRNAnamelist,mRNAexplist)
        usemiRNAexpdict = self.getUsemiRNAdict \
                           (miRNAexplist,miRNAnamelist,\
                            miRNAmRNAtardict,miRNAlncRNAtardict)
        
        list2 = self.gettotalceRNA(miRNAlncRNAtardict, miRNAmRNAtardict)        mulMMIdict = self.computeMulMI(uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict, \
                       miRNAlncRNAtardict, miRNAmRNAtardict)
        sorted_x = sorted(mulMMIdict.iteritems(), key=operator.itemgetter(1),reverse = True)
        print "begin write file"
        self.writeceRNA(ceRNAfile,sorted_x)
        print "Finish"
        


    def writeceRNA(self,filename,sorted_x):
        file_objectW = open(filename,'w')
        try:
            for i in sorted_x:
                for j in i:
                    file_objectW.writelines(str(j)+"\t")
                file_objectW.writelines("\n")
        finally:
            file_objectW.close()

    def computeMulMI(self,uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict, \
                       miRNAlncRNAtardict, miRNAmRNAtardict):
        miRup,miRdown = self.getmiRupdownnumber(uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict, \
                       miRNAlncRNAtardict, miRNAmRNAtardict)
        totalceRNAlist = self.gettotalceRNA(miRNAlncRNAtardict, miRNAmRNAtardict)
        mulMIdict = {}
        totalnum = len(totalceRNAlist)
        count = 0
        doubledict = self.getdoubleXYdict(totalceRNAlist,uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict,miRup,miRdown)
        singledict = self.getsingleXdict(totalceRNAlist,uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict,miRup,miRdown)
        triplist = {}
        for i in totalceRNAlist:
            count = count+1
            print str(count)+"/"+str(totalnum)
            MMI = self.computeMMI(i,totalceRNAlist,uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict,miRup,miRdown,singledict,doubledict)
            mulMIdict[str(i)] = MMI
        return mulMIdict

    def computeMMI(self,AceRNAlist,totalceRNAlist,uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict,miRup,miRdown,singledict,doubledict):
        lncRNAname = AceRNAlist[0]
        miRNAname = AceRNAlist[1]
        mRNAname = AceRNAlist[2]
        lncRNAlist = uselncRNAexpdict[lncRNAname]
        miRNAlist = usemiRNAexpdict[miRNAname]
        mRNAlist = usemRNAexpdict[mRNAname]
        PXYZ = self.computeXYZ(lncRNAlist,miRNAlist,mRNAlist,miRup,miRdown)
        PX = singledict[lncRNAname]
        PY = singledict[miRNAname]
        PZ = singledict[mRNAname]
        t1 = str(lncRNAname)+str(miRNAname)
        t2 = str(lncRNAname)+str(mRNAname)
        t3 = str(miRNAname)+str(mRNAname)
        PXY = doubledict[t1]
        PYZ = doubledict[t2]
        PZX = doubledict[t3]
        rightup = PYZ
        rightdown = PX*PZ
        if rightdown==0.0 or rightup==0.0:
            return 0.0
        right = rightup/rightdown
        MMI = PYZ*math.log(right,2)
        return MMI

    def getsingleXdict(self,totalceRNAlist,uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict,miRup,miRdown):
        totaldict = {}
        kk = 0
        totalceR = len(totalceRNAlist)
        for i in totalceRNAlist:
            kk = kk+1
            print "the single:"+str(kk)+"/"+str(totalceR)
            for j in i:
                if j not in totaldict.keys():
                    Pj = self.computeX(j,totalceRNAlist,uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict,miRup,miRdown)
                    totaldict[j] = Pj
        return totaldict

    def getdoubleXYdict(self,totalceRNAlist,uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict,miRup,miRdown):
        doubledict = {}
        kk = 0
        totalceR = len(totalceRNAlist)
        for i in totalceRNAlist:
            kk = kk+1
            print "the double"+str(kk)+"/"+str(totalceR)
            lncRNAname = i[0]
            miRNAname = i[1]
            mRNAname = i[2]
            t1 = str(lncRNAname)+str(miRNAname)
            t2 = str(lncRNAname)+str(mRNAname)
            t3 = str(miRNAname)+str(mRNAname)
            if t1 not in doubledict.keys():
                PXY = self.computeXY(lncRNAname,miRNAname,totalceRNAlist,uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict,miRup,miRdown)
                doubledict[t1] = PXY
            if t2 not in doubledict.keys():
                PXY = self.computeXY(lncRNAname,mRNAname,totalceRNAlist,uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict,miRup,miRdown)
                doubledict[t2] = PXY
            if t3 not in doubledict.keys():
                PXY = self.computeXY(miRNAname,mRNAname,totalceRNAlist,uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict,miRup,miRdown)
                doubledict[t3] = PXY
        return doubledict
    

    def computeXYZ(self,Xlist,Ylist,Zlist,miRup,miRdown):
        downnum = 0
        upnum = 0
        retnum = 0.0
        for i in range(0,len(Xlist)):
            if Ylist[i]=='0':
                if Xlist[i]=='1' and Zlist[i]=='1':
                    downnum = downnum+1
            else:
                if Xlist[i]=='0' and Zlist[i]=='0':
                    upnum = upnum+1
        retnum = float((downnum+upnum))/float((miRdown+miRup))
        return retnum

    def computeX(self,xname,totalceRNAlist,uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict,miRup,miRdown):
        miR = 0.0
        retnum = 0.0
        downnum = 0.0
        upnum = 0.0
        totaldownnum = 0.0
        totalupnum = 0.0
        for i in totalceRNAlist:
            if xname in i:
                Xlist = uselncRNAexpdict[i[0]]
                Ylist = usemiRNAexpdict[i[1]]
                Zlist = usemRNAexpdict[i[2]]
                downnum,upnum = self.computeupdownXYZ(Xlist,Ylist,Zlist,miRup,miRdown)
                totaldownnum = totaldownnum+downnum
                totalupnum = totalupnum+upnum
        retnum = float((totalupnum+totaldownnum))/float((miRdown+miRup))
        return retnum

    def computeXY(self,xname,yname,totalceRNAlist,uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict,miRup,miRdown):
        miR = 0.0
        downnum = 0.0
        upnum = 0.0
        totaldownnum = 0.0
        totalupnum = 0.0
        retnum = 0.0
        for i in totalceRNAlist:
            if xname in i and yname in i:
                Xlist = uselncRNAexpdict[i[0]]
                Ylist = usemiRNAexpdict[i[1]]
                Zlist = usemRNAexpdict[i[2]]
                downnum,upnum = self.computeupdownXYZ(Xlist,Ylist,Zlist,miRup,miRdown)
                totaldownnum = totaldownnum+downnum
                totalupnum = totalupnum+upnum

        retnum = float((totalupnum+totaldownnum))/float((miRdown+miRup))
        return retnum
        
    def computeupdownXYZ(self,Xlist,Ylist,Zlist,miRup,miRdown):
        downnum = 0
        upnum = 0
        retnum = 0.0
        for i in range(0,len(Xlist)):
            if Ylist[i]=='0':
                if Xlist[i]=='1' and Zlist[i]=='1':
                    downnum = downnum+1
            else:
                if Xlist[i]=='0' and Zlist[i]=='0':
                    upnum = upnum+1
        return downnum,upnum


    def gettotalceRNA(self,miRNAlncRNAtardict, miRNAmRNAtardict):
        miRNAlist1 = miRNAlncRNAtardict.keys()
        miRNAlist2 = miRNAmRNAtardict.keys()
        unionmiRNAlist = [a for a in miRNAlist1 if a in miRNAlist2]
        totalceRNAlist = []
        middlelist = []
        for i in unionmiRNAlist:
            lncRNAlist = miRNAlncRNAtardict[i]
            mRNAlist = miRNAmRNAtardict[i]
            for j in lncRNAlist:
                for k in mRNAlist:
                    middlelist = [j,i,k]
                    totalceRNAlist.append(middlelist)
        return totalceRNAlist

    def getmiRupdownnumber(self,uselncRNAexpdict,usemiRNAexpdict,usemRNAexpdict, \
                       miRNAlncRNAtardict, miRNAmRNAtardict):
        miRNAnamelist = miRNAlncRNAtardict.keys()
        
        miRup = 0;
        miRdown = 0
        middle1 = 0
        middle2 = 0
        for i in miRNAnamelist:
            miRNAexplist = usemiRNAexpdict[i]
            lncRNAnamelist = miRNAlncRNAtardict[i]
            mRNAnamelist = miRNAmRNAtardict[i]
            for j in lncRNAnamelist:
                lncRNAexplist = uselncRNAexpdict[j]
                for k in mRNAnamelist:
                    mRNAexplist = usemRNAexpdict[k]
                    middle1,middle2 = self.getlncRNAmiRNAmRNAupdown(lncRNAexplist,miRNAexplist,mRNAexplist)
                    miRup = miRup+middle1
                    miRdown = miRdown+middle2        
        return miRup,miRdown

    def getlncRNAmiRNAmRNAupdown(self,lncRNAexplist,miRNAexplist,mRNAexplist):
        miRup = 0
        miRdown = 0
        for i in range(0,len(lncRNAexplist)):
            if miRNAexplist[i]=='0':
                if lncRNAexplist[i]=='1' and mRNAexplist[i]=='1':
                    miRdown = miRdown+1
            else:
                if lncRNAexplist[i]=='0' and mRNAexplist[i]=='0':
                    miRup = miRup+1
        return miRup,miRdown
        

    def computeEntropy(self,suppdict,lnRsuppdict,totalnum):
        retdict = {}
        suppnum = 0.0
        confnum = 0.0
        lnRnum = 0.0
        lnRname = ""
        conentropy = 0.0
        for i in suppdict.keys():
            suppnum = float(suppdict[i])/float(totalnum)
            lnRname = i[0]
            lnRnum = float(lnRsuppdict[lnRname])
            confnum = float(suppdict[i])/float(lnRnum)
            conentropy = -1*suppnum*math.log(confnum,2)
            retdict[i] = conentropy
        return retdict
        
    def computeSupp(self,lncRNAexpdic,miRNAexpdic, \
                    mRNAexpdic,miRNAlncRNAtardic,miRNAmRNAtardic):
        retdict = {}
        lncRtotaldict = {}
        miRNAlist = list(set(miRNAlncRNAtardic.keys()).intersection(set(miRNAmRNAtardic.keys())))
        lncRNAlist = []
        miRNAexp = []
        suppnum = 0
        totalnum = 0

        miRNAcount = 0
        miRNAtotal = len(miRNAlist)
        for i in miRNAlist:
            miRNAcount = miRNAcount+1
            lncRNAlist = miRNAlncRNAtardic[i]
            mRNAlist = miRNAmRNAtardic[i]
            miRNAexp = miRNAexpdic[i]
            lncRNAcount = 0
            lncRNAtotal = len(lncRNAlist)
            for j in lncRNAlist:
                lncRNAcount = lncRNAcount+1
                mRNAcount = 0
                mRNAtotal = len(mRNAlist)
                for k in mRNAlist:
                    mRNAcount = mRNAcount+1
                    lncRexp = lncRNAexpdic[j]
                    mRexp = mRNAexpdic[k]
                    suppnum = self.computeNegNum(miRNAexp,lncRexp,mRexp)
                    print "Processing: "+str(miRNAcount)+"/"+str(miRNAtotal)+"\t"+str(lncRNAcount)+"/"+str(lncRNAtotal)+"\t"+str(mRNAcount)+"/"+str(mRNAtotal)
                    if suppnum>0:
                        retdict[(j,i,k)] = suppnum
                        totalnum = totalnum+suppnum
                    if j in lncRtotaldict.keys():
                        lncRtotaldict[j] = lncRtotaldict[j]+suppnum
                    else:
                        lncRtotaldict[j] = suppnum
        return retdict,lncRtotaldict,totalnum

    def computeNegNum(self,miRexp,lnRexp,mRexp):
        num = 0
        for i in range(0,len(miRexp)):
            if lnRexp[i]==mRexp[i] and lnRexp[i]!=miRexp[i]:
                num = num+1
        return num
    
    def getUsemiRNAdict(self,miRNAexplist,miRNAnamelist,mimRtardict,miRlnctardict):
        retdict = {}
        mimRtar = set(mimRtardict.keys())
        milnctar = set(miRlnctardict.keys())
        unidict = mimRtar.union(milnctar)
        for i in unidict:
            num = miRNAnamelist.index(i)
            print num
            print miRNAnamelist[num]
            retdict[miRNAnamelist[num]] = miRNAexplist[num]
        return retdict
    
    def getTarRNAexplist(self,miRNARNAtardict,RNAnamelist,allRNAexp):
        miRNAlncRNAtarnumlist,lncRNAnamelist = \
                self.getTarRNAindex(miRNARNAtardict,RNAnamelist)
        retdict = {}
        retlist = []
        for i in miRNAlncRNAtarnumlist:
            retdict[RNAnamelist[i]] = allRNAexp[i]
        return retdict
                    
    def getTarRNAindex(self,miRNARNAtardict,RNAnamelist):
        tarRNAlist = self.gettarRNAname(miRNARNAtardict)
        retlist = []
        theindex = 0
        namelist = []
        for i in tarRNAlist:
            theindex = RNAnamelist.index(i)
            retlist.append(theindex)
            namelist.append(i)
        return retlist,retlist

    def gettarRNAname(self,miRNARNAtardict):
        retlist = []
        for i in miRNARNAtardict.keys():
            retlist.extend(miRNARNAtardict[i])
        retlist = list(set(retlist))
        return retlist
     
    def readnamefile(self,filename):
        middlestr = ""
        retlist = []
        file_objectR = open(filename,'r')
        try:
            while True:
                line = file_objectR.readline()
                if not line:
                    break
                middlestr = self.handlenamestr(line)
                retlist.append(middlestr)
        finally:
            file_objectR.close()
            return retlist
        
    def readbinaexpfile(self,filename):
        retlist = []
        middlelist = []
        middlelist2 = []
        lines = []
        file_objectR = open(filename,'r')
        try:
            lines = file_objectR.readlines()
            for i in lines:
                middlelist = self.handleexpstr(i)
                retlist.append(middlelist)
        finally:
            file_objectR.close()
            return retlist

    def readTarfile(self,tarfile):
        retdict = {}
        targetname = ""
        valuelist = []
        file_objectR = open(tarfile,'r')
        try:
            while True:
                line = file_objectR.readline()        
                if not line:
                    break
                targetname, valuelist = self.overcomeTarLine(line[:-1])
                retdict[targetname] = valuelist
        finally:
            file_objectR.close()
            return retdict
                
    def overcomeTarLine(self, line):
        begin = 0;
        firststr = ""
        secondstr = ""
        retlist = []
        for i in range(0,len(line)):
            if line[i]=='\t':
                firststr = line[0:i]
                begin = i+1
                secondstr = line[begin:]
                break
        retlist = eval(secondstr)
        return firststr, retlist

    def handleexpstr(self,line):
        hh = line
        middlestr = ""
        retlist = []
        begin = 0
        for i in range(0,len(hh)):
            if hh[i]==',' or hh[i]=='\n':
                middlestr = hh[begin:i]
                begin = i+1
                retlist.append(middlestr)
        return retlist
    
    def handlenamestr(self,line):
        retstr = ""
        for i in range(0,len(line)):
            if line[i]=='\t':
                retstr = line[:i]
                break
        return retstr
        
    def handlestring(self,line):
        begin = 0
        end = 0
        middlelist = []
        retlist = []
        for i in line:
            if i!='\t':
                end = end+1
            else:
                middlelist.append(line[begin:end])
                begin = end+1
                end = end+1
        if len(middlelist)==12 and float(middlelist[-3])!=0.0:
            retlist.append(self.removenumber(middlelist[6]))
            retlist.append(middlelist[-3])
        return retlist
    
    def removenumber(self,thestring):
        retstring = ""
        for i in range(len(thestring)-1,-1,-1):
            if thestring[i]==':':
                retstring = thestring[0:i]
                return retstring
        return retstring

        
if __name__=="__main__":
    h = readfile("aa")
    h.complexhandlefile()
