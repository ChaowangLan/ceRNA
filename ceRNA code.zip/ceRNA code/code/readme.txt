The main program is "computeentropy.py"

In this program, we only compute the competiton score of the ceRNA crosstalk mediated by hsa-miR-198.
If you want to compute the competiton score of the ceRNA crosstalk mediated by another miRNA, please change the file "predicttarget/targetmRNAmiRNA.txt and "predicttarget/targetlncRNAmiRNA.txt". 

"predicttarget/targetmRNAmiRNA.txt"  stores the miRNA target mRNAs.
"predicttarget/targetlncRNAmiRNA.txt" stores the miRNA target lncRNAs.

The target lncRNA and mRNA are store in the "ERdata/total targets". 

The input of our program are:
the lncRNA expression value: newdata/finalhavelncRNA.txt
the miRNA expression value: newdata/ERhavemiRNA.txt
the mRNA expression value: newdata/finalhavegene.txt
lncRNA binary matrix: newdata/binarylncRNA.txt (This file is transformed from the lncRNA expression value file newdata/finalhavelncRNA.txt)
miRNA binary matrix: newdata/binarymiRNA.txt(This file is transformed from the miRNA expression value file "newdata/ERhavemiRNA.txt")
mRNA binary matrix: newdata/binarygene.txt(This file is transformed from the mRNA expression value file "newdata/finalhavegene.txt")
miRNA target mRNA file: predicttarget/targetmRNAmiRNA.txt
miRNA target lncRNA file: predicttarget/targetlncRNAmiRNA.txt


The output of our program:
"ERdata/MMIceRNA.txt"

